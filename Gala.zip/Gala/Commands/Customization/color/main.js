exports.about = 'Change theme color'; // About

exports.parameter = ['command']; // Parameter