const functions = require("../../functions.js"); // Functions

function run (message, client) { // Command
    client.guilds.get(message.guild.id).channels.forEach(function (channel) {

    });
}

const about = 'Manage the server', // About
    paramaters = ['command']; // Paramaters