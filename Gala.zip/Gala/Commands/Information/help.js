const fs = require("fs");
const settings = require("../../settings.json");
var msg;

module.exports = {
    run: function (message) {
        msg = "__**Gala's Commands**__\n";

        fs.readdir("./Commands", function(err, items) {
            for (var i = 0; i < items.length; i++) {
                next(items[i], items.length, i);
            }
        });

        function next(item, len, i) {
            fs.readdir("./Commands/"+item, function(err, items2) {
                for (var x = 0; x < items2.length; x++) {
                    var command = require("../"+item+"/"+items2[x]);

                    if (msg.indexOf(item) > -1) {
                        msg += items2[x].replace(".js", "")+" - "+command.about()+"\n";
                    } else {
                        msg += "\n**"+item+"**\n"+items2[x].replace(".js", "")+" - "+command.about()+"\n";
                    }

                     if (i+1 >= len && x+1 >= items2.length) {
                        done();
                    }
                }
            });
        }

        function done() {
            message.author.send({embed: {
                color: settings.colors.neutral,
                description: msg
            }});
        }

        message.channel.send({embed: {
            color: settings.colors.success,
            description: message.author + ", I have sent you my instruction manual."
        }});
    },
    about: function () {
        return "Sends what I can do."
    }
};