exports.about = 'Manage thiccness.'; // About

exports.parameter = ['mention', 'command']; // Parameter