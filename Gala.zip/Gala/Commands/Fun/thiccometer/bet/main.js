const functions = require("../../functions.js"), // Functions
fs = require("fs"), // File system
data = require("../../data.json"); // Data

exports.run = function (message, client, data) { // Command
    if (message.content[2] == 'all') { //Check for all subcommand
        if (message.member.roles.some(r=>data.adminRoles.includes(r.name))) { // Check if user has an admin role
            fs.readFile('./data.json', 'utf8', function readFileCallback (err, data) { // Read file
                let obj = JSON.parse(data); // Convert to list

                client.guilds.get(message.guild.id).members.forEach( function (member) { // Get each member
                    if (obj.users.length === 0) { // Check if list is empty
                        obj.users.push({name: member.user.username, id: member.user.id, value: Math.round(Math.random()*200)}); //Create random thiccness starting value
                    } else {
                        for (let a = 0; a < obj.users.length; a++) { // Loop through values
                            if (obj.users[a].id == member.user.id) { // Check if id matches author
                                obj.users[a].value += Math.round(Math.random()*obj.users[a].value/3+5-obj.users[a].value/6-5); // Add or subtract thiccness randomly
                                obj.users[a].name = member.user.username; // Update name
                                a = obj.users.length; // Stop loop
                            } else if (a+1 == obj.users.length) { // Check for last loop
                                obj.users.push({name: member.user.username, id: member.user.id, value: Math.round(Math.random()*200)}); //Create random thiccness starting value
                                a = obj.users.length; // Stop loop
                            }
                        }
                    }
                });

                json = JSON.stringify(obj); // Convert to json
                fs.writeFile('./data.json', json, 'utf8', function(err, result) { // Write to json
                    if(err) console.log('error', err); // Log error
                });
            });

            functions.write(message, 'sucess', "All member's thiccness updated.", obj); // Send output
        } else {
            functions.write(message, 'error', 'You have insufficient permissions to use the command ' + message.content[1] + ', ' + message.author.username); // Send denial message
        }
    } else if (message.content[3] == 'bet') {
        const member = message.mentions.members.first(); // Get first mention

        if (member !== undefined) { // Check if mention exists
            fs.readFile('./data.json', 'utf8', function readFileCallback (err, data) { // Read file
                let obj = JSON.parse(data); // Convert to list

                if (obj.users.length === 0) { // Check if list is empty
                    obj.users.push({name: member.user.username, id: member.user.id, value: Math.round(Math.random()*200)}); //Create random thiccness starting value
                    functions.write(message, 'sucess', member.user.username + ' is ' + obj.users[0].value + '% thicc!', obj); // Send output
                } else {
                    for (let a = 0; a < obj.users.length; a++) { // Loop through values
                        if (obj.users[a].id == member.user.id) { // Check if id matches author
                            obj.users[a].value += Math.round(Math.random()*(obj.users[a].value/3+2)-(obj.users[a].value/6+1)); // Add or subtract thiccness randomly
                            obj.users[a].name = member.user.username; // Update name
                            functions.write(message, 'sucess', member.user.username + ' is ' + obj.users[a].value + '% thicc!', obj); // Send output
                            a = obj.users.length; // Stop loop
                        } else if (a+1 == obj.users.length) { // Check for last loop
                            obj.users.push({name: member.user.username, id: member.user.id, value: Math.round(Math.random()*200)}); //Create random thiccness starting value
                            functions.write(message, 'sucess', member.user.username + ' is ' + obj.users[a+1].value + '% thicc!', obj); // Send output
                            a = obj.users.length; // Stop loop
                        }
                    }
                }

                json = JSON.stringify(obj); // Convert to json
                fs.writeFile('./data.json', json, 'utf8', function(err, result) { // Write to json
                    if(err) console.log('error', err); // Log error
                });
            });
        }
    } else {
        const member = message.mentions.members.first(); // Get first mention

        if (member !== undefined) { // Check if mention exists
            fs.readFile('./data.json', 'utf8', function readFileCallback (err, data) { // Read file
                let obj = JSON.parse(data); // Convert to list

                for (let a = 0; a < obj.users.length; a++) { // Loop through values
                    if (obj.users[a].id == member.user.id) { // Check if id matches author
                        obj.users[a].name = member.user.username; // Update name
                        functions.write(message, 'sucess', member.user.username + ' is ' + obj.users[a].value + '% thicc!', obj); // Send output
                        a = obj.users.length; // Stop loop
                    } else if (a+1 == obj.users.length) { // Check for last loop
                        obj.users.push({name: member.user.username, id: member.user.id, value: Math.round(Math.random()*200)}); //Create random thiccness starting value
                        functions.write(message, 'sucess', member.user.username + ' is ' + obj.users[a+1].value + '% thicc!', obj); // Send output
                        a = obj.users.length; // Stop loop
                    }
                }
            });
        }
    }
}