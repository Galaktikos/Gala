// Functions
const functions = require("../../functions.js");

// Modules
module.exports = {
    run: function (message) {
        functions.write(message, 'sucess', 'Ping!');
    },
    about: function () {
        return "Ping!";
    }
}; 