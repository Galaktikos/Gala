// Functions
const functions = require("../../functions.js");

// Modules
module.exports = {
    run: function (message) {
        functions.write(message, 'sucess', 'Pong!');
    },
    about: function () {
        return "Pong!";
    }
}; 